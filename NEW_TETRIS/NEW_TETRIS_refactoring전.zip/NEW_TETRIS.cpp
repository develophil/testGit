// NEW_TETRIS.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
	GameManager gm;

    gm.introGame();

    return 0;
}
