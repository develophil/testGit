#include "stdafx.h"

// class constructor
Tetrimino::Tetrimino()
{
	// insert your code here
}


// class constructor
Tetrimino::Tetrimino(short _boxSize, short _type, short _color, char *_shape)
{
    //cout << "������ȣ��!" << endl;
    

	boxSize = _boxSize;
	type = _type;
	color = _color;
	shape = _shape;
    //coord = (COORD *)malloc(sizeof(COORD)*4);
    coord = new COORD[4];
    xy = new COORD{0,0};
    
}

// class destructor
Tetrimino::~Tetrimino()
{
	// insert your code here
    //free(coord);
    delete[] coord;
	delete xy;
}

// ��������
void Tetrimino::clearBlock()
{
	SetCursor(false);
    for(int i=0; i<BLOCK_SIZE; i++)
    {
        gotoxy((xy->X) + ((coord+i)->X), (xy->Y) + ((coord+i)->Y));
        printf("%s","  ");
    }
}

// �������
void Tetrimino::printBlock()
{
	SetCursor(false);
    setcolor((int)color,BLACK);
    for(int i=0; i<BLOCK_SIZE; i++)
    {
        gotoxy((xy->X) + ((coord+i)->X), (xy->Y) + ((coord+i)->Y));
        printf("%s",shape);
    }
}


