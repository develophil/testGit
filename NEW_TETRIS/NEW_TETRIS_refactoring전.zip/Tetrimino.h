#pragma once

enum BLOCK_TYPE {I,J,L,O,S,T,Z};
const char BLOCK_SHAPE[4][3] = {"  ","��","��","��"};

class Tetrimino
{
      public:
              short boxSize;
              short type;
              short color;
              char *shape;
              COORD *coord;
              COORD *xy;
	

		// class constructor
		Tetrimino();
		Tetrimino(short boxSize, short type, short color, char *shape);		
		// class destructor
		~Tetrimino();
		
		// ����� 

        // ��������
        void clearBlock();
        // �������
        void printBlock();

        
};
