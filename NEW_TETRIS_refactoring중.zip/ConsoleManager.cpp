#include "stdafx.h"
#include "ConsoleManager.h"


ConsoleManager::ConsoleManager()
{
}


ConsoleManager::~ConsoleManager()
{
}



void ConsoleManager::gotoxy(short x, short y)
{
	COORD pos = { x * 2, y };
	SetConsoleCursorPosition(COL, pos);
}

void ConsoleManager::printGotoxy(short x, short y, char str[])
{
	SetCursor(false);
	COORD pos = { x * 2, y };
	SetConsoleCursorPosition(COL, pos);
	printf("%s", str);
}
void ConsoleManager::printGotoxy(short x, short y, char str[], int color)
{
	setcolor(color, BLACK);
	printGotoxy(x, y, str);
}
void ConsoleManager::setcolor(int color, int bgcolor)
{
    color &= 0xf;
    bgcolor &= 0xf;
    SetConsoleTextAttribute(COL, (bgcolor << 4) | color);
}

void ConsoleManager::SetCursor(bool bVisible)
{
	CONSOLE_CURSOR_INFO ConsoleCursor;
	ConsoleCursor.bVisible = bVisible; // true ����, false �Ⱥ���
	ConsoleCursor.dwSize = 1; // Ŀ��������
	SetConsoleCursorInfo(COL, &ConsoleCursor); // ����
}