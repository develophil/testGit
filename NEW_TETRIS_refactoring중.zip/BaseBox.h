#pragma once

typedef struct Tile
{
	short innerX;
	short innerY;
	short bgColor;
	short txtColor;
	char shape[3];

	Tile();
	Tile(short aI, short aJ, short aBgColor, short aTxtColor, char aShape[]) {
		innerX = aI;
		innerY = aJ;
		bgColor = aBgColor;
		txtColor = aTxtColor;
		strcpy_s(shape, aShape);
	};
} Tile;


class BaseBox
{

protected:
	short posX;
	short posY;
	short width;
	short height;
	Tile *tiles;
	char *blueprint;

public:
	virtual void initTiles() = 0;	// û������ �̿��� Ÿ�� ��ü ���� ����
	virtual void moveBlock() = 0;	// �̵�
	virtual void printBlock() = 0;	// ���
	virtual void clearBlock() = 0;	// ����

	
};

