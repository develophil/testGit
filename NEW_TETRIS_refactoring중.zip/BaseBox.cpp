#include "stdafx.h"

BaseBox::BaseBox()
{
	
}


BaseBox::~BaseBox()
{

}



// ��������
void BaseBox::clearBlock()
{
	SetCursor(false);
	for (int i = 0; i<BLOCK_SIZE; i++)
	{
		gotoxy((xy->X) + ((coord + i)->X), (xy->Y) + ((coord + i)->Y));
		printf("%s", "  ");
	}
}

// �������
void BaseBox::printBlock()
{
	SetCursor(false);
	setcolor((int)color, BLACK);
	for (int i = 0; i<BLOCK_SIZE; i++)
	{
		gotoxy((xy->X) + ((coord + i)->X), (xy->Y) + ((coord + i)->Y));
		printf("%s", shape);
	}
}


