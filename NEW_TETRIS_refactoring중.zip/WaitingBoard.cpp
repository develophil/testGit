#include "stdafx.h"
#include "WaitingBoard.h"


WaitingBoard::WaitingBoard()
{
}


WaitingBoard::~WaitingBoard()
{
}
