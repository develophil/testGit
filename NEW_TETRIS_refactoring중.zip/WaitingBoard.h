#pragma once
class WaitingBoard : public BaseBox
{
	Tetrimino	*waitingBlock;

public:
	WaitingBoard();
	~WaitingBoard();
};

