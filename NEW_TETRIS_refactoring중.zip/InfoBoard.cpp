#include "stdafx.h"
#include "InfoBoard.h"


InfoBoard::InfoBoard()
{
}


InfoBoard::~InfoBoard()
{
}
